<?php


interface ISquare
{
    function squareArea(float $sideSquare);
}