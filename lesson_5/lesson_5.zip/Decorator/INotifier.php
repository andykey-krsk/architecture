<?php

interface INotifier
{
    public function sendNotification();
}