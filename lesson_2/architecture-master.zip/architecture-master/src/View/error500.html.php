<!DOCTYPE html>
<html>
<head>
    <title>On-line курсы GeekStars | 500 error</title>
</head>
<body>
    <pre>
<?php
            echo $error . PHP_EOL;
            echo $trace;
?>
    </pre>
</body>
</html>