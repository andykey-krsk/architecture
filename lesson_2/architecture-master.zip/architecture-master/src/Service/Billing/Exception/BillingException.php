<?php

declare(strict_types = 1);

namespace Service\Billing\Exception;

class BillingException extends \Exception
{
}
