<?php

declare(strict_types = 1);

namespace Service\Communication\Exception;

class CommunicationException extends \Exception
{
}
