<?php
define('ROOT_DIR', dirname(__DIR__));
define('DS', DIRECTORY_SEPARATOR);