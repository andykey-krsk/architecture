<?php


interface ICircle
{
    function circleArea(float $circumference);
}